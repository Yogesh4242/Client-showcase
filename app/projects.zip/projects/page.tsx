"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Projects() {
  const router = useRouter();
  
  // State to track expanded text for mobile view
  const [expanded, setExpanded] = useState<{ [key: number]: boolean }>({});

  const toggleExpand = (id: number) => {
    setExpanded((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const goToProject = (id: number) => {
    if (id === 1) router.push("/projects/project1");
    if (id === 2) router.push("/projects/project2");
    if (id === 3) router.push("/projects/project3");
    if (id === 4) router.push("/projects/project4");
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=Manrope:wght@300;400;500&family=Marcellus&display=swap');

        :root {
          --gold:         #d4af37;
          --gold-muted:   #8c7322;
          --bg:           #070707;
          --bg-surface:   #0f0f0f;
          --border:       rgba(212, 175, 55, 0.2);
          --text-main:    #f5f5f5;
          --text-muted:   #a1a1aa;
        }

        *{
          box-sizing:border-box;
          margin:0;
          padding:0;
        }

        body{
          background: var(--bg);
          color: var(--text-main);
          -webkit-font-smoothing: antialiased;
          overflow-x: hidden;
        }

        /* ─── TYPOGRAPHY ─── */
        h2, h3, .brand-font {
          font-family: 'Marcellus', serif;
          font-weight: 400; 
        }

        p, span, a, button {
          font-family: 'Manrope', sans-serif;
        }

        /* ─── HERO ─── */
        .hero{
          padding: 140px 20px 80px;
          max-width: 1000px;
          margin: auto;
          text-align: center;
        }

        .hero h1 {
          font-family: 'Cormorant Garamond', serif;
          font-size: clamp(2.2rem, 8vw, 4.5rem); 
          font-weight: 700; 
          line-height: 1.1;
          letter-spacing: -0.02em;
          background: linear-gradient(45deg, #c59b48 0%, #fcf6ba 25%, #b38728 50%, #fbf5b7 75%, #8c6014 100%);
          background-size: 200% auto;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          filter: drop-shadow(0px 8px 16px rgba(197, 155, 72, 0.25));
        }

        .section{
          max-width: 1200px;
          margin: auto;
          padding: 40px 20px;
        }

        .section-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          border-bottom: 1px solid var(--border);
          padding-bottom: 20px;
          margin-bottom: 30px;
          flex-wrap: wrap;
          gap: 10px;
        }

        .section-title{
          font-size: clamp(1.3rem, 5vw, 2rem);
          color: var(--gold);
          letter-spacing: 0.05em;
          text-transform: uppercase;
          background: linear-gradient(to right, #bf953f, #fcf6ba, #b38728, #fbf5b7, #aa771c);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          margin-right: 15px;
        }

        .section-subtitle {
          color: var(--text-muted);
          font-size: clamp(0.75rem, 3vw, 0.85rem);
          text-transform: uppercase;
          letter-spacing: 0.15em;
        }

        /* ─── GRID ─── */
        .project-row{
          display: grid;
          gap: 0; 
        }

        @media(min-width:900px){
          .project-row{
            grid-template-columns: 1.5fr 1fr;
            border: 1px solid var(--border);
          }
          .reverse{
            grid-template-columns: 1fr 1.5fr;
          }
          .project-row > div:first-child {
            border-right: 1px solid var(--border);
          }
        }

        /* ─── CARD & HOVER EFFECTS ─── */
        .project-card{
          width: 100%;
          height: 100%; 
          min-height: 300px;
          position: relative;
          cursor: pointer;
          overflow: hidden;
          background: #000;
          display: flex; 
        }

        .project-card img{
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
          transition: transform 0.8s cubic-bezier(0.25, 1, 0.5, 1), filter 0.6s ease;
          opacity: 1; 
          filter: blur(0px) brightness(1); 
        }

        .project-card:hover img{
          transform: scale(1.05);
          filter: blur(8px) brightness(0.6); 
        }

        .view-3d {
          position: absolute;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 2;
          opacity: 0;
          transform: translateY(15px);
          transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
          pointer-events: none; 
        }

        .view-3d span {
          background: rgba(0, 0, 0, 0.4);
          backdrop-filter: blur(4px);
          -webkit-backdrop-filter: blur(4px);
          border: 1px solid rgba(212, 175, 55, 0.5);
          color: var(--text-main);
          padding: 10px 24px;
          border-radius: 40px;
          font-family: 'Manrope', sans-serif;
          font-size: 0.75rem;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }

        .project-card:hover .view-3d {
          opacity: 1;
          transform: translateY(0);
        }

        .overlay{
          position: absolute;
          inset: 0;
          display: flex;
          flex-direction: column;
          justify-content: flex-end;
          padding: 30px 20px;
          background: linear-gradient(to top, rgba(0,0,0,0.8) 0%, transparent 60%);
          z-index: 1;
        }

        .overlay h3{
          font-size: clamp(1.5rem, 5vw, 2rem);
          color: var(--text-main);
          transform: translateY(10px);
          transition: transform 0.4s ease;
        }

        .project-card:hover .overlay h3 {
          transform: translateY(0);
          color: var(--gold);
        }

        /* ─── INFO CARD ─── */
        .info-card{
          background: var(--bg-surface);
          padding: 40px 25px;
          display: flex;
          flex-direction: column;
          justify-content: center;
          height: 100%;
        }

        .info-number {
          font-size: 0.8rem;
          color: var(--gold-muted);
          margin-bottom: 15px;
          letter-spacing: 0.1em;
          text-transform: uppercase;
        }

        .info-title{
          font-size: clamp(1.5rem, 5vw, 1.8rem);
          margin-bottom: 15px;
          color: var(--text-main);
        }

        .info-text{
          font-size: 0.9rem;
          font-weight: 300;
          line-height: 1.7;
          color: var(--text-muted);
          transition: all 0.3s ease;
        }

        /* View More Button (Mobile Only) */
        .view-more-btn {
          display: none;
          background: none;
          border: none;
          color: var(--gold);
          font-size: 0.75rem;
          text-transform: uppercase;
          letter-spacing: 0.15em;
          padding: 0;
          margin-top: 15px;
          cursor: pointer;
          width: fit-content;
          border-bottom: 1px solid transparent;
          transition: border-bottom 0.3s ease;
        }

        .view-more-btn:hover {
          border-bottom: 1px solid var(--gold);
        }

        /* ─── MOBILE ONLY ADJUSTMENTS ─── */
        @media(max-width:899px){
          .project-row{
            grid-template-columns: 1fr;
            border: 1px solid var(--border);
            margin-bottom: 30px;
          }
          
          .project-row > .project-card {
            order: -1;
          }

          .project-row > div:first-child {
            border-right: none;
            border-bottom: 1px solid var(--border);
          }

          .hero { padding: 100px 20px 50px; }
          
          .hero h1 {
            line-height: 1.2; 
            filter: drop-shadow(0px 4px 8px rgba(197, 155, 72, 0.35));
          }

          /* Handle Line Clamping */
          .clamped {
            display: -webkit-box;
            -webkit-line-clamp: 4;
            -webkit-box-orient: vertical;
            overflow: hidden;
          }

          .view-more-btn {
            display: block;
          }
        }
      `}</style>
      <div>

     {/* Add a Hero section here and also add something that matches the page */}
      
        {/* <section className="hero">
          <h1>
            Building the future with innovative infrastructure solutions.
          </h1>
        </section> */}


        <section className="hero">
          <h1>
          </h1>
        </section> 

        {/* SECTION 1 - Terrace Landscape */}
        <section className="section">
          <div className="section-header">
            <h2 className="section-title">The Terrace Garden</h2>
            <span className="section-subtitle">Residential</span>
          </div>

          <div className="project-row">
            <div className="project-card" onClick={() => goToProject(1)}>
              <img src="/p1 preview.jpeg" alt="Terrace Landscape"/>
              <div className="view-3d"><span>View in 3D</span></div>
              <div className="overlay"><h3></h3></div>
            </div>

            <div className="info-card">
              <span className="info-number">01 - Sowcarpet</span>
              <h3 className="info-title">A Breathable Oasis</h3>
              <p className={`info-text ${expanded[1] ? "" : "clamped"}`}>
                Located in the dense urban fabric of Sowcarpet, this project required a careful balance between expansion and structural feasibility.
Using lightweight construction methods, we enabled vertical growth without compromising stability.
The terrace was transformed into a refined, functional landscape — creating a calm, usable space above the active commercial environment.
              </p>
              <button className="view-more-btn" onClick={() => toggleExpand(1)}>
                {expanded[1] ? "View Less —" : "View More +"}
              </button>
            </div>
          </div>
        </section>

        {/* SECTION 2 - NOVA (Villa) */}
        <section className="section">
          <div className="section-header">
            <h2 className="section-title">NOVA (Villa)</h2>
            <span className="section-subtitle">Residential</span>
          </div>

          <div className="project-row reverse">
            <div className="info-card">
              <span className="info-number">02 - [Location To Be Filled]</span>
              <h3 className="info-title">Modern Living</h3>
              <p className={`info-text ${expanded[2] ? "" : "clamped"}`}>Set on a challenging plot with irregular geometry, this project required a precise and adaptive design approach.
Our team optimized the layout to resolve spatial constraints while maintaining comfort and usability.
The 2-bedroom villa is aligned with Vastu principles and finished with a refined façade, delivering a balanced and premium living space.</p>
              <button className="view-more-btn" onClick={() => toggleExpand(2)}>
                {expanded[2] ? "View Less —" : "View More +"}
              </button>
            </div>

            <div className="project-card" onClick={() => goToProject(2)}>
              <img src="/image2.png" alt="NOVA Villa"/>
              <div className="view-3d"><span>View in 3D</span></div>
              <div className="overlay"><h3></h3></div>
            </div>
          </div>
        </section>

        {/* SECTION 3 - Canteen */}
        <section className="section">
          <div className="section-header">
            <h2 className="section-title">Canteen</h2>
            <span className="section-subtitle">Commercial / Healthcare</span>
          </div>

          <div className="project-row">
            <div className="project-card" onClick={() => goToProject(3)}>
              <img src="/p3 preview.jpeg" alt="Hospital Canteen"/>
              <div className="view-3d"><span>View in 3D</span></div>
              <div className="overlay"><h3></h3></div>
            </div>

            <div className="info-card">
              <span className="info-number">03 - Canteen, [Locality To Be Filled]</span>
              <h3 className="info-title">Functional Design</h3>
              <p className={`info-text ${expanded[3] ? "" : "clamped"}`}>
                Executed within an active hospital environment, this project required careful coordination to ensure zero disruption to patients and medical staff.
Our team managed material handling and on-site operations with precision, maintaining a smooth and controlled workflow throughout.

By combining an underutilized storeroom and washroom, we developed a functional canteen space — delivering a much-needed facility with efficiency and clarity.
              </p>
              <button className="view-more-btn" onClick={() => toggleExpand(3)}>
                {expanded[3] ? "View Less —" : "View More +"}
              </button>
            </div>
          </div>
        </section>

        {/* SECTION 4 - Apache Residence */}
        <section className="section">
          <div className="section-header">
            <h2 className="section-title">Apache Residence</h2>
            <span className="section-subtitle">Residential</span>
          </div>

          <div className="project-row reverse">
            <div className="info-card">
              <span className="info-number">04 // [Location To Be Filled]</span>
              <h3 className="info-title">Contemporary Comfort</h3>
              <p className={`info-text ${expanded[4] ? "" : "clamped"}`}>
                Defined by sharp lines and a neutral palette, Apache Residence is a masterclass in modern minimalism. The structural layout favors high ceilings and broad floorplates, allowing for a voluminous sense of space. Sustainable cooling techniques were integrated into the framework to ensure comfort throughout the seasons.
              </p>
              <button className="view-more-btn" onClick={() => toggleExpand(4)}>
                {expanded[4] ? "View Less —" : "View More +"}
              </button>
            </div>

            <div className="project-card" onClick={() => goToProject(4)}>
              <img src="/p4 preview.jpeg" alt="Apache Residence"/>
              <div className="view-3d"><span>View in 3D</span></div>
              <div className="overlay"><h3></h3></div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}